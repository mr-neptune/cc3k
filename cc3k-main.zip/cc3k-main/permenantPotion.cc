#include "permenantPotion.h"

PermenantPotion::PermenantPotion(int x, int y, GameObject* below) : Potion(x, y, below) {}

PermenantPotion::~PermenantPotion() {}
