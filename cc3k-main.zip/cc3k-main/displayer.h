#ifndef DISPLAYER_H
#define DISPLAYER_H

class Displayer {
    public:
        virtual void display() = 0;
};

#endif
