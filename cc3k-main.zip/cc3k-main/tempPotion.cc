#include "tempPotion.h"

Temppotion::Temppotion(int x, int y, GameObject *below) : Potion(x, y, below) {}

Temppotion::~Temppotion() {}
